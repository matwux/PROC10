//variables gameState

var PLAY = 1;
var END = 0;
var gameState = PLAY;

//variables de objetos del lobby
var path, pathImg;
var player, playerImg;
var shop, shopImg;
var bro, broImg;
var michael, michaelImg;


function preload() {

pathImg = loadImage("MAPA.png");
playerImg = loadImage("knight.png");
//shopImg = loadImage("tienda1.png, tienda2.png, tienda3.png, tienda4.png, tienda5.png");


}

function setup() {
createCanvas(500, 300 )

path = createSprite(250, 150, 1365, 625);
path.addImage("MAPA", pathImg);
//path.scale = 2;

shop = createSprite(100, 100, 10, 10);
//shop.addAnimation("shop animation", shopImg);

player = createSprite(30, 312, 10, 10);
//playerImg.addImage("player_cube", playerImg);


}

function draw() {
    background("gray");
    
    if (gameState === PLAY) {

        if (keyDown("w")) {
            player.y = 3;
        }
    }

    drawSprites()



}