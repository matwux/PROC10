var p5Inst = new p5(null, 'sketch');

window.preload = function () {
  initMobileControls(p5Inst);

  p5Inst._predefinedSpriteAnimations = {};
  p5Inst._pauseSpriteAnimationsByDefault = false;
  var animationListJSON = {"orderedKeys":["c3bd5632-c9d4-4fad-8182-92f724788e99","718f9e35-5064-4b0d-8d25-9e0a9229416c"],"propsByKey":{"c3bd5632-c9d4-4fad-8182-92f724788e99":{"name":"cat","sourceUrl":null,"frameSize":{"x":100,"y":100},"frameCount":1,"looping":true,"frameDelay":12,"version":"OzXehdck3TINVi0WIaBjuNzPt2QImKpT","loadedFromSource":true,"saved":true,"sourceSize":{"x":100,"y":100},"rootRelativePath":"assets/c3bd5632-c9d4-4fad-8182-92f724788e99.png"},"718f9e35-5064-4b0d-8d25-9e0a9229416c":{"name":"cheese","sourceUrl":null,"frameSize":{"x":100,"y":100},"frameCount":1,"looping":true,"frameDelay":12,"version":"z7Uadrlc_h4403N2OmO.9ib.6WTD8JgM","loadedFromSource":true,"saved":true,"sourceSize":{"x":100,"y":100},"rootRelativePath":"assets/718f9e35-5064-4b0d-8d25-9e0a9229416c.png"}}};
  var orderedKeys = animationListJSON.orderedKeys;
  var allAnimationsSingleFrame = false;
  orderedKeys.forEach(function (key) {
    var props = animationListJSON.propsByKey[key];
    var frameCount = allAnimationsSingleFrame ? 1 : props.frameCount;
    var image = loadImage(props.rootRelativePath, function () {
      var spriteSheet = loadSpriteSheet(
          image,
          props.frameSize.x,
          props.frameSize.y,
          frameCount
      );
      p5Inst._predefinedSpriteAnimations[props.name] = loadAnimation(spriteSheet);
      p5Inst._predefinedSpriteAnimations[props.name].looping = props.looping;
      p5Inst._predefinedSpriteAnimations[props.name].frameDelay = props.frameDelay;
    });
  });

  function wrappedExportedCode(stage) {
    if (stage === 'preload') {
      if (setup !== window.setup) {
        window.setup = setup;
      } else {
        return;
      }
    }
// -----

//sprites de personajes
var cat = createSprite(20, 380, 15, 15);
cat.shapeColor="orange";
var milk_bowl = createSprite(380, 20, 25, 25);

//sprites de paredes
var wall1 = createSprite(80, 300, 20, 400);
var wall2 = createSprite(160, 100, 20, 400);
var wall3 = createSprite(190, 290, 50, 20);
var wall4 = createSprite(270, 270, 20, 400);
var wall5 = createSprite(340, 100, 20, 400);
var wall6 = createSprite(190, 230, 50, 20);
var wall7 = createSprite(190, 170, 50, 20);
var falseWall = createSprite(380, 80, 60, 20);
falseWall.shapeColor="red";

//potenciadores

var moreVelocity = createSprite(35, 200, 70, 20);
moreVelocity.shapeColor="yellow";
var moreVelocity2 = createSprite(120, 250, 60, 20);
moreVelocity2.shapeColor="yellow";
var button = createSprite(190, 260, 10, 10);
button.shapeColor="red";

//enemigos

var rat1 = createSprite(35, 165, 15, 15);
rat1.velocityX=5;
var rat2 = createSprite(120, 190, 15, 15);
rat2.velocityX=3;
var rat3 = createSprite(160, 320, 15, 15);
rat3.velocityY=7;
var rat4 = createSprite(195, 200, 15, 15);
rat4.velocityX=5;

var sierra1 = createSprite(305, 100, 15, 15);
var sierra2 = createSprite(305, 160, 15, 15);
var sierra3 = createSprite(305, 220, 15, 15);

function draw() {
  background(220)
  
  if (keyDown("w")) {
    cat.y= cat. y-4
  }
  if (keyDown("s")) {
  cat.y= cat. y+4
}
if (keyDown("d")){
  cat.x= cat. x+4
}
if (keyDown("a")){
  cat.x= cat. x-4
}

if (cat.isTouching(moreVelocity)) {
  if (keyDown("w")) {
    cat.y= cat. y-10
  }
  if (keyDown("s")) {
  cat.y= cat. y+10
}
if (keyDown("d")){
  cat.x= cat. x+10
}
if (keyDown("a")){
  cat.x= cat. x-10
}
}

if (cat.isTouching(moreVelocity2)) {
  if (keyDown("w")) {
    cat.y= cat. y-10
  }
  if (keyDown("s")) {
  cat.y= cat. y+10
}
if (keyDown("d")){
  cat.x= cat. x+10
}
if (keyDown("a")){
  cat.x= cat. x-10
}
}

if (cat.isTouching(button)) {
  button.destroy();
  falseWall.destroy();
}
  
if (cat.isTouching(rat1) || cat.isTouching(rat2) || cat.isTouching(rat3) || cat.isTouching(rat4) || cat.isTouching(sierra1) || cat.isTouching(sierra2) || cat.isTouching(sierra3)) {
  rat1.velocityX=0;
  rat2.velocityX=0;
  rat3.velocityY=0;
  rat4.velocityX=0;
   text("reinicia desde el principio",100,350);
  
}

if (cat.isTouching(milk_bowl)) {
  rat1.velocityX=0;
  rat2.velocityX=0;
  rat3.velocityY=0;
  rat4.velocityX=0;
  text("ganaste",100,350);
}
  
  
  
  createEdgeSprites()
  
  //colisiones de cat
  cat.bounceOff(wall1);
  cat.bounceOff(wall2);
  cat.bounceOff(wall3);
  cat.bounceOff(wall4);
  cat.bounceOff(wall5);
  cat.bounceOff(wall6);
  cat.bounceOff(wall7);
  cat.bounceOff(edges);
  rat1.bounceOff(wall1);
  rat1.bounceOff(edges);
  rat2.bounceOff(wall1);
  rat2.bounceOff(wall2);
  rat3.bounceOff(wall2);
  rat3.bounceOff(edges);
  rat4.bounceOff(wall2);
  rat4.bounceOff(wall4);
  
  
  
  drawSprites()
}


// -----
    try { window.draw = draw; } catch (e) {}
    switch (stage) {
      case 'preload':
        if (preload !== window.preload) { preload(); }
        break;
      case 'setup':
        if (setup !== window.setup) { setup(); }
        break;
    }
  }
  window.wrappedExportedCode = wrappedExportedCode;
  wrappedExportedCode('preload');
};

window.setup = function () {
  window.wrappedExportedCode('setup');
};
