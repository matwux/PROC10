var gameState = lobby
var gameState = fight1
var gameState = fight2
var gameState = fight3
var gameState = fight4
var gameState = fight5
var gameState = fight6
var gameState = DIE 

function preload() {

}

function setup() {
createCanvas(1000, 1000 )


}